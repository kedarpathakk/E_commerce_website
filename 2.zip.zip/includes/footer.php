<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>All rights reserved</b>
      </div>
      <strong>Copyright &copy; 2021 Brought to You By  <a href="#">Vinay And Team</a></strong>
    </div>
</footer>